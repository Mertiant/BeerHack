    



    var fill = 100;
    var update = setInterval(function() {
        fill -= 1;
        $('#fillIcon').css('height', (fill+'%')); 
        if (fill === 40) {
            clearInterval(update);        
        }
    }, 100);

    var fill1 = 100;
    var update1 = setInterval(function() {
        fill1 -= 1;
        $('#fillIcon1').css('height', (fill1+'%')); 
        if (fill1 === 60) {
            clearInterval(update1);        
        }
    }, 100);





    var fill2 = 100;
    var update2 = setInterval(function() {
        fill2 -= 1;
        $('#fillIcon2').css('height', (fill2+'%')); 
        if (fill2 === 40) {
            clearInterval(update2);        
        }
    }, 100);

    var fill3 = 100;
    var update3 = setInterval(function() {
        fill3 -= 1;
        $('#fillIcon3').css('height', (fill3+'%')); 
        if (fill3 === 30) {
            clearInterval(update3);        
        }
    }, 100);


    var fill4 = 100;
    var update4 = setInterval(function() {
        fill4 -= 1;
        $('#fillIcon4').css('height', (fill4+'%')); 
        if (fill4 === 40) {
            clearInterval(update4);        
        }
    }, 100);

    var fill5 = 100;
    var update5 = setInterval(function() {
        fill5 -= 1;
        $('#fillIcon5').css('height', (fill5+'%')); 
        if (fill5 === 30) {
            clearInterval(update5);        
        }
    }, 100);





    var fill6 = 100;
    var update6 = setInterval(function() {
        fill6 -= 1;
        $('#fillIcon6').css('height', (fill6+'%')); 
        if (fill6 === 40) {
            clearInterval(update6);        
        }
    }, 100);

    var fill7 = 100;
    var update7 = setInterval(function() {
        fill7 -= 1;
        $('#fillIcon7').css('height', (fill7+'%')); 
        if (fill7 === 30) {
            clearInterval(update7);        
        }
    }, 100);